# SimpleNetwork

<pre><code>
$ ./server 5050 1 <br>
$ ./client 127.0.0.1 5050 message
</code></pre>
