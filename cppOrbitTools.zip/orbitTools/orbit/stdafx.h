//
// stdafx.h
//
#pragma once

#include "math.h"
#include "time.h"

#include "coreLib.h"

using namespace std;